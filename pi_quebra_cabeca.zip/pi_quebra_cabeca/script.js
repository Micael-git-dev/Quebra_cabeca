const puzzleContainer = document.getElementById('puzzle');
const shuffleButton = document.getElementById('shuffleButton');
const showImageButton = document.getElementById('showImageButton');
const messageDiv = document.getElementById('message');
const imageModal = document.getElementById('imageModal');
const fullImage = document.getElementById('fullImage');
const closeModal = document.querySelector('.close');
const imageUrl = 'img/controle.jpg'; // Caminho da imagem

let pieces = [];
let emptyPieceIndex = 8;

// Gera as peças do quebra-cabeça
function initPuzzle() {
    for (let i = 0; i < 9; i++) {
        if (i < 8) {
            pieces.push(i);
        } else {
            pieces.push(''); // Peça vazia
        }
    }
    shuffle(pieces);
    renderPuzzle();
}

// Renderiza o quebra-cabeça na tela
function renderPuzzle() {
    puzzleContainer.innerHTML = '';
    pieces.forEach((piece, index) => {
        const pieceDiv = document.createElement('div');
        pieceDiv.classList.add('piece');
        if (piece === '') {
            pieceDiv.classList.add('empty');
        } else {
            pieceDiv.style.backgroundImage = `url(${imageUrl})`;
            pieceDiv.style.backgroundPosition = `-${(piece % 3) * 100}px -${Math.floor(piece / 3) * 100}px`;
            pieceDiv.setAttribute('draggable', true);
            pieceDiv.addEventListener('dragstart', dragStart);
            pieceDiv.addEventListener('dragover', dragOver);
            pieceDiv.addEventListener('drop', drop);
        }
        pieceDiv.addEventListener('click', () => handlePieceClick(index));
        puzzleContainer.appendChild(pieceDiv);
    });
    highlightMovablePieces();
    checkWin();
}

// Embaralha as peças
function shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
}

// Destaca as peças que podem ser movidas
function highlightMovablePieces() {
    const emptyRow = Math.floor(emptyPieceIndex / 3);
    const emptyCol = emptyPieceIndex % 3;

    pieces.forEach((piece, index) => {
        const row = Math.floor(index / 3);
        const col = index % 3;

        if ((Math.abs(row - emptyRow) === 1 && col === emptyCol) || 
            (Math.abs(col - emptyCol) === 1 && row === emptyRow)) {
            puzzleContainer.children[index].classList.add('movable');
        } else {
            puzzleContainer.children[index].classList.remove('movable');
        }
    });
}

// Manipuladores de eventos para arrastar e soltar
function dragStart(e) {
    e.dataTransfer.setData('text/plain', e.target.style.backgroundPosition);
    emptyPieceIndex = Array.from(puzzleContainer.children).indexOf(e.target);
}

function dragOver(e) {
    e.preventDefault();
}

function drop(e) {
    e.preventDefault();
    const dropIndex = Array.from(puzzleContainer.children).indexOf(e.target);
    if (dropIndex !== emptyPieceIndex) {
        movePieces(emptyPieceIndex, dropIndex);
    }
}

// Função para lidar com o clique na peça
function handlePieceClick(index) {
    const row = Math.floor(index / 3);
    const col = index % 3;
    const emptyRow = Math.floor(emptyPieceIndex / 3);
    const emptyCol = emptyPieceIndex % 3;

    if ((Math.abs(row - emptyRow) === 1 && col === emptyCol) || 
        (Math.abs(col - emptyCol) === 1 && row === emptyRow)) {
        movePieces(emptyPieceIndex, index);
    }
}

// Função para mover as peças e adicionar animação
function movePieces(fromIndex, toIndex) {
    const piecesContainer = Array.from(puzzleContainer.children);
    const pieceToMove = piecesContainer[fromIndex];

    pieceToMove.style.transition = 'transform 0.3s ease';
    pieceToMove.style.transform = `translate(${(toIndex % 3 - fromIndex % 3) * 100}px, ${(Math.floor(toIndex / 3) - Math.floor(fromIndex / 3)) * 100}px)`;
    
    setTimeout(() => {
        [pieces[fromIndex], pieces[toIndex]] = [pieces[toIndex], pieces[fromIndex]];
        emptyPieceIndex = toIndex;
        renderPuzzle();
    }, 300);
}

// Função para verificar se o quebra-cabeça foi completado
function checkWin() {
    const isWin = pieces.every((piece, index) => piece === index || (piece === '' && index === 8));
    if (isWin) {
        showVictoryMessage();
    }
}

// Função para mostrar a mensagem de vitória
function showVictoryMessage() {
    messageDiv.innerHTML = `
        <div>🌟🎉 Parabéns! 🎉🌟</div>
        <div style="font-size: 24px;">Você completou o quebra-cabeça!</div>
        <button id="restartButton">🔄 Reiniciar</button>
    `;
    messageDiv.classList.add('visible');

    document.getElementById('restartButton').addEventListener('click', () => {
        pieces = [];
        emptyPieceIndex = 8;
        initPuzzle();
        messageDiv.classList.remove('visible');
    });
}

shuffleButton.addEventListener('click', () => {
    pieces = [];
    emptyPieceIndex = 8;
    initPuzzle();
});

// Função para abrir o modal com a imagem
showImageButton.addEventListener('click', () => {
    fullImage.src = imageUrl;
    imageModal.style.display = "block"; // Exibe o modal
});

// Função para fechar o modal
closeModal.addEventListener('click', () => {
    imageModal.style.display = "none"; // Esconde o modal
});

// Fecha o modal ao clicar fora da imagem
window.addEventListener('click', (event) => {
    if (event.target === imageModal) {
        imageModal.style.display = "none";
    }
});

// Inicializa o quebra-cabeça
initPuzzle();
